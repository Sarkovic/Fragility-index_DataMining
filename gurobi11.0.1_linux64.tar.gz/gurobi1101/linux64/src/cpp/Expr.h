// Copyright (C) 2024, Gurobi Optimization, LLC
// All Rights Reserved
#ifndef _CPP_EXPR_H_
#define _CPP_EXPR_H_

class GRBExpr
{
  private:

  public:
    friend class GRBModel;
};
#endif
